=============================
Plone 3 Unified Installer
=============================
The Plone Unified Installer is a source-installation kit that installs
Plone and its dependencies from source on most Unix-like platforms. The
kit includes Plone, Zope and Python. Python is installed in a way that
will not change or interfere with your system Python.

This version includes Plone 3.0.5, Zope 2.10.5, and Python 2.4.4.

New in this version: options for stand-alone and root-less installs. See
below.

Original Author: Kamal Gill (kamalgill at mac.com)
Maintainers for Plone 3: Steve McMahon (steve at dcn.org) and Kamal Gill (kamalgill at mac.com)
Feedback/bug reports: http://dev.plone.org/plone
This document last modified: 5 Jan 2008

*Important:* Back up your existing Plone site prior to running the installer.


Installation Instructions
=========================
The installer will compile Python, Zope, and all required libraries from
source.

PLEASE NOTE: You have the option to run the installation as root or a
normal user. There are serious security implications to this choice.

The non-root method produces an install that will run the Zope server
with the same privileges as the installing user. This is probably not an
acceptable security profile for a production server, but may be
acceptable for testing and development purposes.

The 'root' method produces an install that runs the Zope server as a
distinct user identity with minimal privileges (unless you add them).
Providing adequate security for a production server requires many more
steps, but this is a better starting point.

PLEASE NOTE: You have the option to install Plone as a standalone
(single-instance) setup or as a clustered (ZEO) setup.

The clustered (ZEO) setup will take advantage of multi-core CPUs and is
recommended for a production deployment, while the standalone method is
recommended for a desktop-based development setup.

For more detail on both root/non-root and ZEO/standalone choices, see
"Installing Plone 3 with the Unified Installer":http://plone.org/documentation/tutorial/installing-plone-3-with-the-unified-installer
in the Plone.Org documentation section.


For a super-user (root) installation
------------------------------------
If you run the installation with root privileges, it will install
Python/Zope/Plone to /opt/Plone-3.0.5 and will -- if necessary -- build
libz (compression) and libjpeg (JPG manipulation) libraries in
/usr/local. A "plone" user will be added, and Zope will be configured to
run under that user id. You will need to start Zope as root or via sudo.

To install Plone 3 in a stand-alone (single Zope instance) configuration:

* cd to the installer directory and issue the following command:
	>> sudo ./install.sh standalone (or `su; ./install.sh standalone` on a sudo-less system)

To install Plone 3 in a ZEO Cluster (ZEO server, 2 clients) configuration:

* cd to the installer directory and issue the following command:
	>> sudo ./install.sh zeo (or `su; ./install.sh zeo` on a sudo-less system)

For a non-super-user (rootless) installation
--------------------------------------------
If you run the installation while logged in as a normal (non-root) user,
Python/Zope/Plone will be built at $HOME/Plone-3.0.5 (the user's home
directory, Plone-3.0.5 subdirectory). You will need to start Zope using
the user identity used for the build, and it will run with the
privileges of that user.

To install Plone 3 in a stand-alone (single Zope instance) configuration:

* cd to the installer directory and issue the following command:
	>> ./install.sh standalone

To install Plone 3 in a ZEO Cluster (ZEO server, 2 clients) configuration:

* cd to the installer directory and issue the following command:
	>> ./install.sh zeo


Upgrade Instructions
====================
See UPGRADING.txt


Dependencies
============
1) gcc
2) g++ (gcc-c++)
3) GNU make
4) GNU tar (must support -z and --bzip2 arguments)
5) posix-compliant /bin/sh


Recommended libraries and utilities (install prior to running installer)
Development versions of some packages are required for headers.
==========================================================
* readline (Python command-line history)
     libreadline5 libreadline5-dev readline-common
* libssl (SSL support, used by SecureMailHost for TLS)
     libssl libssl-dev
3) libxml2 (used by marshall) 
     libxml libxml-dev
* wv (used to index Word documents)
     wv
     <http://wvware.sourceforge.net/>
* xpdf (used to index PDFs)
     xpdf
     <http://www.foolabs.com/xpdf/download.html>


Install Location, Root Install
==============================
- Plone installed at /opt/Plone-3.0.5
- Python installed at /opt/Plone-3.0.5/Python-2.4.4
- For ZEO Cluster
	- ZEO cluster (server and 2 clients) installed and configured at /opt/Plone-3.0.5/zeocluster
	- Zope Products folder at /opt/Plone-3.0.5/zeocluster/Products
	- Data.fs (ZODB) at /opt/Plone-3.0.5/zeocluster/server/var
	- adminPassword.txt at /opt/Plone-3.0.5/zeocluster/adminPassword.txt
- For Stand-Alone:
	- Zope Instance installed and configured at /opt/Plone-3.0.5/zinstance
	- Zope Products folder at /opt/Plone-3.0.5/zinstance/Products
	- Data.fs (ZODB) at /opt/Plone-3.0.5/zinstance/var
	- adminPassword.txt at /opt/Plone-3.0.5/zinstance/adminPassword.txt


Install Location, Root-less Install
===================================
- Plone installed at $HOME/Plone-3.0.5 where $HOME is the user's home directory
- Python installed at $HOME/Plone-3.0.5/Python-2.4.4
- For ZEO Cluster
	- ZEO cluster (server and 2 clients) installed and configured at $HOME/Plone-3.0.5/zeocluster
	- Zope Products folder at $HOME/Plone-3.0.5/zeocluster/Products
	- Data.fs (ZODB) at $HOME/Plone-3.0.5/zeocluster/server/var
	- adminPassword.txt at /opt/Plone-3.0.5/zinstance/adminPassword.txt
- For Stand-Alone:
	- Zope Instance installed and configured at /opt/Plone-3.0.5/zinstance
	- Zope Products folder at /opt/Plone-3.0.5/zinstance/Products
	- Data.fs (ZODB) at $HOME/Plone-3.0.5/zinstance/var
	- adminPassword.txt at $HOME/Plone-3.0.5/zinstance/adminPassword.txt


Startup/Shutdown/Restart/Status instructions
=====================================

Root Install
------------
Stand-Alone:
	To start Plone, 
		>> sudo /opt/Plone-3.0.5/zinstance/bin/zopectl start

	To stop Plone,
		>> sudo /opt/Plone-3.0.5/zinstance/bin/zopectl stop
	
	To check status,
		>> sudo /opt/Plone-3.0.5/zinstance/bin/zopectl status

ZEO Cluster:
	To start Plone, 
		>> sudo /opt/Plone-3.0.5/zeocluster/bin/startcluster.sh

	To stop Plone,
		>> sudo /opt/Plone-3.0.5/zeocluster/bin/shutdowncluster.sh

	To restart Plone,
		>> sudo /opt/Plone-3.0.5/zeocluster/bin/restartcluster.sh

	To check status,
		>> sudo /opt/Plone-3.0.5/zeocluster/bin/clusterstatus.sh
	
Root-less Install
-----------------
Stand-Alone:
	To start Plone, 
		>> $HOME/Plone-3.0.5/zinstance/bin/zopectl start

	To stop Plone,
		>> $HOME/Plone-3.0.5/zinstance/bin/zopectl stop

	To check status,
		>> $HOME/Plone-3.0.5/zinstance/bin/zopectl status
	
ZEO Cluster:
	To start Plone, 
		>> $HOME/Plone-3.0.5/zeocluster/bin/startcluster.sh

	To stop Plone,
		>> $HOME/Plone-3.0.5/zeocluster/bin/shutdowncluster.sh

	To restart Plone,
		>> $HOME/Plone-3.0.5/zeocluster/bin/restartcluster.sh

	To check status,
		>> $HOME/Plone-3.0.5/zeocluster/bin/clusterstatus.sh


Ports
=====
Stand-Alone:
	- Zope server runs on port 8080

	Edit zinstance/etc/zope.conf to change ports.

ZEO Cluster:
	- ZEO server runs on port 8100
	- ZEO client1 runs on port 8080
	- ZEO client2 runs on port 8081

	Edit zeocluster/server/etc/zeo.conf,
	zeocluster/client1/etc/zope.conf,
	zeocluster/client2/etc/zope.conf to change ports.

	Note: Remember to change the port each ZEO client
	connects to if the ZEO server's port is modified. 
	Look for the line with "server localhost:8100"
	in zeocluster/client*/etc/zope.conf
	  <zeoclient>
    		server localhost:8100
    		storage 1
    		name zeostorage
    		var $INSTANCE/var
	  </zeoclient>


Post-installation instructions
==============================
You should be able to view the Zope Management Interface at:

    http://localhost:8080/manage

And, your new Plone at::

    http://localhost:8080/Plone

(Use the admin password provided at yourinstance/adminPassword.txt)

Select "Plone site" from the "Add item" drop-down menu near top right to
add a Plone site. This only needs to be done once for each Plone site
you wish to add.

To change the admin password, click the "Password" link for the admin
user at:

    http://localhost:8080/acl_users/users/manage_users 


Third-party products installed
==============================
- PIL (Python Imaging Library)
- ElementTree (Python XML file library)
- libjpeg (JPEG library, usually installed to /usr/local/lib)
- libz (compression, usually installed to /usr/local/lib)
- openid-python (supports Plone OpenID authentication; optional)
- libxml2-python (required for Marshall support)
- feedparser (Python RSS library)


Known Problems
==============
NOTE: The Zope installation routine does not set the python path in the
#! line of some scripts in bin. This should not affect normal Zope
operations, but may cause some of the supplementary utilities to use the
wrong python. Edit the #! line to use the local python if you encounter
this problem.


Platform Notes
==============
The install script requires a POSIX-compliant version of sh. If your
version of sh fails on test expressions, you may need to edit the
install script to specify use of zsh, bash or a later version of sh.

The install script requires several GNU build utilities such as gcc,
g++, make and tar. You may need to edit the install script to specify
their locations and names. Also, the tar flag for bzip2 compression is
not the same on all platforms. If your tar utility does not accept
"--bzip2", you'll need to change the TAR_BZIP2_FLAG setting in install.sh.

The install script tries to find zlib and libjpeg libraries. If it can't
find them, it installs them (to /usr/local for a root install). If the
library detection code in the installation script doesn't meet your
needs, you may force a particular choice by editing the script.


Tested on the following operating environments
==============================================
- Ubuntu 6.06, 6.10, 7.04 Server
- FreeBSD 6.1 (with addition of /opt)
- Solaris 10
  (edit install.sh to specify /bin/zsh or /bin/bash rather than /bin/sh;
   edit tool paths for make and tar)
- Fedora Core 6
- Fedora 7 (64-bit PowerPC, x86_64)
- Mac OS X 10.4 and 10.5
  (with Xcode tools; make sure to reinstall XCode when you upgrade to Leopard.
   On Leopard, it's strongly advised to install the MacPorts version of the
   readline library before running the Unified Installer.)
- SUSE LES 10


Uninstall instructions
======================
1) Stop Plone
2) Remove folder /opt/Plone-3.0.5 or $HOME/Plone-3.0.5


Backup instructions
===================
1) Stop Plone
2) Back up folder /opt/Plone-3.0.5 or $HOME/Plone-3.0.5
   >> tar -zcvf Plone-3.0.5-backup.tgz /opt/Plone-3.0.5

Live backup is possible. See http://plone.org/documentation/how-to/backup-plone


Coexistence with System Python
==============================
The Python installed by the Unified Installer should *not* interfere with
any other Python on your system.  The Installer bundles Python 2.4.4,
placing it at /opt/Plone-3.0.5/Python-2.4.4 or $HOME/Plone-3.0.5/Python-2.4.4.


Installer Bug reports
=====================
Please use the Plone issue tracker at http://dev.plone.org/plone for all
bug reports.


Credits
=======
Thanks for Naotaka Jay Hotta for suggesting -- and offering an initial
implementation for -- stand-alone and cluster configuration options.

Thanks to Larry T of the Davis Plone Group for the first implementation
of the rootless install.

Thanks to Alex Clark and Raphael Ritz for help with creation of a Plone
site in the initial database.

Thanks to the Davis (California) Plone Users Group for helping with
testing.

Thanks to Barry Page and Larry Pitcher for their work on the init scripts.
