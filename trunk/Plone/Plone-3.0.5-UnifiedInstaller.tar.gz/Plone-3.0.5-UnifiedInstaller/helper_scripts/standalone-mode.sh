############################################################################
# Unified Plone installer build script
# stand-alone instance builder.
# Author: Kamal Gill (kamalgill at mac.com)
# Adapted for Plone 3 by Steve McMahon (steve at dcn.org)
############################################################################

# Most of this script is derived from the zeocluster script,
# so, it's convenient to use ZEOCLUSTER_HOME for the instance
# home -- even though it's not a zeo cluster.
ZEOCLUSTER_HOME=$RINSTANCE_HOME

PRODUCTS_HOME=$ZEOCLUSTER_HOME/Products
INSTANCE_LIB_HOME=$ZEOCLUSTER_HOME/lib
ZEOCLIENT1_HOME=$ZEOCLUSTER_HOME
PWFILE=$ZEOCLUSTER_HOME/adminPassword.txt
RECEIPTS_HOME=$PLONE_HOME/receipts


########################################
# Create Instance
echo "Creating Instance ..."
$PLONE_HOME/bin/mkzopeinstance.py --dir=$RINSTANCE_HOME --user=admin:$PASSWORD	


#####################################
# Set effective-user in etc/zope.conf
if [ $ROOT_INSTALL -eq 1 ]
then
	mv $ZEOCLIENT1_HOME/etc/zope.conf $ZEOCLIENT1_HOME/etc/zope.conf.tmp
	cat $ZEOCLIENT1_HOME/etc/zope.conf.tmp | sed 's/^.*#.*effective-user.*chrism.*$/effective-user plone/g' > $ZEOCLIENT1_HOME/etc/zope.conf
	rm $ZEOCLIENT1_HOME/etc/zope.conf.tmp
fi


###############################################################
# Extract and move Plone tarball to Products folder of Instance
echo "Extracting Plone tarball ..."
cd $ZEOCLUSTER_HOME
$GNU_TAR --bzip2 -xf $PKG/$PLONE_TB 
# Products subdirectory becomes Products
mv $PLONE_DIR/Products/* $PRODUCTS_HOME/
# lib subdirectory contents moved to lib/python
mv $PLONE_DIR/lib/python/* $INSTANCE_LIB_HOME/python/
rm -r $PLONE_DIR

# set permissions that will allow plone user to write .pyc files
if [ $ROOT_INSTALL -eq 1 ]
then
	chown -R plone $PRODUCTS_HOME
	chown -R plone $INSTANCE_LIB_HOME
	# set group also
	if [ "x$PGROUP" != "x" ]
	then
		chgrp -R $PGROUP $PRODUCTS_HOME
		chgrp -R $PGROUP $INSTANCE_LIB_HOME
	fi
fi
chmod -R 755 $PRODUCTS_HOME
chmod -R 755 $INSTANCE_LIB_HOME
cd $PKG


########################
# Write password to file
echo "Writing random password to file ..."
# Write admin password and startup/shutdown info to password file
echo "Use the account information below to log into the Zope Management Interface" > "$PWFILE"
echo "The account has full 'Manager' privileges." >> "$PWFILE"
echo " " >> "$PWFILE"
echo "  Username: admin" >> "$PWFILE"
echo "  Password: $PASSWORD" >> "$PWFILE"
echo " " >> "$PWFILE"
echo "Before you start Plone, you should review the settings in:" >> "$PWFILE"
echo " " >> "$PWFILE"
echo "  $ZEOCLIENT1_HOME/etc/zope.conf" >> "$PWFILE"
echo " " >> "$PWFILE"
echo "Adjust the ports Plone uses before starting the site, if necessary" >> "$PWFILE"
echo " " >> "$PWFILE"
echo "To start Plone, issue the following command in a Terminal window:" >> "$PWFILE"
echo " " >> "$PWFILE"
echo "  $SUDO $ZEOCLIENT1_HOME/bin/zopectl start" >> "$PWFILE"
echo " " >> "$PWFILE"
echo "To stop Plone, issue the following command in a Terminal window:" >> "$PWFILE"
echo " " >> "$PWFILE"
echo "  $SUDO $ZEOCLIENT1_HOME/bin/zopectl stop" >> "$PWFILE"
echo " " >> "$PWFILE"



######################################
## Clean up any .DS_Store files (OS X)
find $PLONE_HOME -name '.DS_Store' -delete


###########################################
# Set appropriate ownership and permissions
echo "Setting appropriate file ownership and permissions ..."
chmod 600 "$PWFILE"
if [ $ROOT_INSTALL -eq 1 ]
then
	chown plone $ZEOCLIENT1_HOME/var
	chown plone $ZEOCLIENT1_HOME/log
fi


###############################
# Create a Plone instance at /Plone in the ZODB
# via zopectl run script.
echo "Creating Plone site at /Plone in ZODB ..."
cp $CWD/$HSCRIPTS_DIR/mkPloneSite.py $ZEOCLIENT1_HOME/bin/
cd $ZEOCLIENT1_HOME/bin/
touch empty.py
$ZEOCLIENT1_HOME/bin/zopectl run empty.py
$ZEOCLIENT1_HOME/bin/zopectl run $ZEOCLIENT1_HOME/bin/mkPloneSite.py 2> $ZEOCLIENT1_HOME/log/firststart.log
if [ "$?" != "0" ]
then
	echo "Attempt to create a Plone site in the Zope instance failed."
	echo "You will need to do this manually."
fi
rm $ZEOCLIENT1_HOME/bin/mkPloneSite.py
