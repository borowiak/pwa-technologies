This directory contains a collection of startup scripts, often
called init.d or rc.d scripts, for various platforms. These scripts
are meant for use in root installs to cause the Zope/Plone server to
start and shutdown with the system.

Look for a subdirectory for your platform. If your platform is missing,
don't despair: one of the existing init.d scripts may be very close to
what you need.

PLEASE NOTE: If you edited your ./install.sh script to install Plone to 
an alternative location, you will need to edit the sample init script 
you choose to reflect the change.