These are rudimentary, but useable, startup scripts for Mac OS X.

For a standalone (no ZEO) configuration, copy the Plone-Standalone directory
to /Library/StartupItems:

sudo cp -R Plone-Standalone /Library/StartupItems/Plone

For a ZEO cluster configuration, copy the Plone-Cluster directory
to /Library/StartupItems:

sudo cp -R Plone-Cluster /Library/StartupItems/Plone