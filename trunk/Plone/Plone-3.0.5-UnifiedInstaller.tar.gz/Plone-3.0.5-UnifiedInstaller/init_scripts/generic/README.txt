This directory contains rudimentary, classic-style init scripts that will
work on many systems. Installation will vary by system.

Note that, although these scripts may work on your system, it's nearly always
better to use the startup script style specific to your platform.